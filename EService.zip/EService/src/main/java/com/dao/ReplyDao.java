package com.dao;

import com.models.Reply;

import java.util.List;

public interface ReplyDao {
    void create(Reply reply);
    void update(Reply reply);
    void delete(Reply reply);
    Reply readOne(Integer reply_id);
    List<Reply> readAll();
}
