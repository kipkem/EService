package com.dao;

import com.models.User;

import java.util.List;

public interface UserDao {
    void create(User user);
    void update(User user);
    void delete(User user);
    User readOne(Integer user_id);
    List<User> readAll();
}
