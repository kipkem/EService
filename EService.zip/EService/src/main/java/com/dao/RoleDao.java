package com.dao;

import com.models.Role;

import java.util.List;

public interface RoleDao {
    void create(Role role);
    void update(Role role);
    void delete(Role role);
    Role readOne(Integer role_id);
    List<Role> readAll();
}
