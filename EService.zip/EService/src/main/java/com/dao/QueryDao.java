package com.dao;

import com.models.Query;

import java.util.List;

public interface QueryDao {
    void create(Query query);
    void update(Query query);
    void delete(Query query);
    Query readOne(Integer query_id);
    List<Query> readAll();
}
