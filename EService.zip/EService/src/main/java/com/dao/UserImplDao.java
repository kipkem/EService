package com.dao;

import com.models.User;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
@Transactional
public class UserImplDao implements UserDao{

    @PersistenceContext
    private EntityManager e;

    public void create(User user) {
        e.persist(user);
    }

    public void update(User user) {

    }

    public void delete(User user) {

    }

    public User readOne(Integer user_id) {
        User u = e.find(User.class, user_id );
        return u;
    }

    public List<User> readAll() {
        List<User> users = e.createQuery("select a from User a", User.class).getResultList();
        return users;
    }

}
