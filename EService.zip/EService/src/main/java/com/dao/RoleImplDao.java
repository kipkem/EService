package com.dao;

public class RoleImplDao {
}
