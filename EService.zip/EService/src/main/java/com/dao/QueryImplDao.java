package com.dao;

public class QueryImplDao {
}
