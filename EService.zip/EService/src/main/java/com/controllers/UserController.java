package com.controllers;

import com.dao.UserDao;
import com.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class UserController {

    @Autowired
    private UserDao u;

    @RequestMapping(value = "/users", method = RequestMethod.GET)
    public String landingPage(Model model){
        List<User> users = u.readAll();
        model.addAttribute("users", users);
        System.out.println(users.toString());
        return "index";
    }
}
