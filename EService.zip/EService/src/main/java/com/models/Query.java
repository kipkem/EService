package com.models;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="queries")
public class Query {
    @Id
    @GeneratedValue
    private Integer query_id;

    @NotEmpty
    private String query_title;
    private String query_description;
    private Timestamp query_created_dt;

    @ManyToOne
    @JoinColumn(name="user_id")
    private User user_id;

    public Integer getQuery_id() {
        return query_id;
    }

    public void setQuery_id(Integer query_id) {
        this.query_id = query_id;
    }

    public String getQuery_title() {
        return query_title;
    }

    public void setQuery_title(String query_title) {
        this.query_title = query_title;
    }

    public String getQuery_description() {
        return query_description;
    }

    public void setQuery_description(String query_description) {
        this.query_description = query_description;
    }

    public Timestamp getQuery_created_dt() {
        return query_created_dt;
    }

    public void setQuery_created_dt(Timestamp query_created_dt) {
        this.query_created_dt = query_created_dt;
    }

    public User getUser_id() {
        return user_id;
    }

    public void setUser_id(User user_id) {
        this.user_id = user_id;
    }

    @Override
    public String toString() {
        return "Query{" +
                "query_id=" + query_id +
                ", query_title='" + query_title + '\'' +
                ", query_description='" + query_description + '\'' +
                ", query_created_dt='" + query_created_dt + '\'' +
                ", user_id=" + user_id +
                '}';
    }
}
