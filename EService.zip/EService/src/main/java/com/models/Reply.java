package com.models;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="replies")
public class Reply {
    @Id
    @GeneratedValue

    private Integer reply_id;

    @NotEmpty
    private String reply_comment;
    private Timestamp reply_created_dt;

    @ManyToOne
    @JoinColumn(name="user_id")
    private User user_id;

    @ManyToOne
    @JoinColumn(name="query_id")
    private Query query_id;

    public Integer getReply_id() {
        return reply_id;
    }

    public void setReply_id(Integer reply_id) {
        this.reply_id = reply_id;
    }

    public String getReply_comment() {
        return reply_comment;
    }

    public void setReply_comment(String reply_comment) {
        this.reply_comment = reply_comment;
    }

    public Timestamp getReply_created_dt() {
        return reply_created_dt;
    }

    public void setReply_created_dt(Timestamp reply_created_dt) {
        this.reply_created_dt = reply_created_dt;
    }

    public User getUser_id() {
        return user_id;
    }

    public void setUser_id(User user_id) {
        this.user_id = user_id;
    }

    public Query getQuery_id() {
        return query_id;
    }

    public void setQuery_id(Query query_id) {
        this.query_id = query_id;
    }

    @Override
    public String toString() {
        return "Reply{" +
                "reply_id=" + reply_id +
                ", reply_comment='" + reply_comment + '\'' +
                ", reply_created_dt='" + reply_created_dt + '\'' +
                ", user_id=" + user_id +
                ", query_id=" + query_id +
                '}';
    }
}
