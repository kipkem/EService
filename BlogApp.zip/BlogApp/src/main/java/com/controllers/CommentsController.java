package com.controllers;

import com.dao.CommentsDao;
import com.models.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller

public class CommentsController {
    @Autowired
    private CommentsDao c;

    @RequestMapping(value ="/comments", method = RequestMethod.GET)
    public String indexPage(Model model){
        List<Comment> comments = c.readAll();
        model.addAttribute("comments",comments);
        return "comments";
    }



    @RequestMapping(value = "/createComments", method = RequestMethod.GET)
    public String createComment(Model model){
        Comment comment  = new Comment();
        model.addAttribute("comment", comment);
        return "createComments";
    }


    @RequestMapping(value = "/saveComments", method = RequestMethod.POST)
    public String saveComment(Model model, @ModelAttribute("comment")Comment comment){
        c.create(comment);

        List<Comment> comments = c.readAll();
        model.addAttribute("comments",comments);
        return "comments";
    }


}
