package com.controllers;

import com.dao.CommentsDao;
import com.dao.PostsDao;
import com.models.Comment;
import com.models.Post;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.jws.WebParam;
import java.util.List;

@Controller

public class PostsController {
    @Autowired
    private PostsDao p;

    @Autowired
    private CommentsDao c;

    @RequestMapping(value = "/posts", method = RequestMethod.GET)
    public String landingPage(Model model){
        List<Post> posts = p.readAll();
        model.addAttribute("posts", posts);
        System.out.println(posts.toString());
        return "index";
    }

    @RequestMapping(method = RequestMethod.POST)
    public String savePost(Model model,@ModelAttribute("post")Post post){
       p.create(post);
       return "Success";
    }

    @RequestMapping(value = "/getPost/{id}", method = RequestMethod.GET)
    public String getOnePost(@PathVariable("id") int id, Model model){

        Post post = p.readOne(id);
        model.addAttribute("singlepost", post);

        List<Comment> comments = c.readByPostId(id);
        model.addAttribute("postComments", comments);

        return "onepost";
    }
}
